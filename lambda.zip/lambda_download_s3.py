##
# Lambda function that updates the sensors' data for the last hour.
#

import requests, boto3, json

##
# Definition of the name, the key and the boto3 client to access the S3 bucket 
# where the sensors' data files are stored, as well as the url where the json 
# for the sensors' data for the last hour is stored.
#

S3_BUCKET = "trm-cu-cc-aqi-bucket"
S3_KEY = "data.json"
s3 = boto3.client("s3")
url = "https://data.sensor.community/static/v2/data.1h.json"

##
# Lambda's routine
#

def lambda_handler(event, context):

    # Get the file from the url
    resp = requests.get(url)

    # Read the data
    full_data = resp.json()

    # Create the list where the data for the relevant sensors (those that measure PM10 and 
    # PM2.5 particles) will be stored
    data = []

    # For every sesnsor listed in the json, check if it measures PM10 and/or PM2.5 particles
    for x in full_data:
        for dv in x["sensordatavalues"]:
            if dv["value_type"] in ("P1", "P2"):
                # If true, append all the sensor's data to the relevant sensors list
                data.append(x)
                break

    # Upload the relevant sesnors' data to the S3 bucket
    s3.put_object(
        Bucket=S3_BUCKET,
        Key=S3_KEY,
        Body=json.dumps(data, indent=2)
    )

    # Return a 200 OK status code showing the S3 key
    return {
        "statusCode": 200,
        "body": json.dumps({
            "message": f"Uploaded {S3_KEY} to S3 successfully",
            "s3_key": S3_KEY
        })
    }