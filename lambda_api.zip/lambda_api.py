##
# Lambda function that handles the GET request from the API.
#

import json
import boto3
from botocore.exceptions import ClientError

##
# Definition of the name and the boto3 client to access the S3 bucket where the results are stored.
#

s3 = boto3.client("s3")
BUCKET = "trm-cu-cc-aqi-bucket"


##
# Lambda's routine
#

def lambda_handler(event, context):
    # Retrieve the job id from the API gateway GET message
    job_id = event.get("queryStringParameters", {}).get("job_id")

    # If there is no job id present in the message, return a Bad Request with the needed CORS headers
    if not job_id:
        return {
            "statusCode": 400,
            "headers": {
                "Access-Control-Allow-Origin": "*"
            },
            "body": json.dumps({"error": "job_id missing"})
        }

    # Create the S3 bucket key for the result
    key = f"results/{job_id}.json"

    try:
        # Get the result from the bucket
        obj = s3.get_object(Bucket=BUCKET, Key=key)
        data = obj["Body"].read().decode("utf-8")

        # Return to the API the result with a 200 OK status code and the needed CORS headers
        return {
            "statusCode": 200,
            "headers": {
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Headers": "Content-Type",
                "Access-Control-Allow-Methods": "GET,OPTIONS"
            },
            "body": data
        }

    except ClientError as e:
        # If there is no result in the S3 bucket, return to the API 
        # a pending status with a 200 OK status code and the needed CORS headers
        if e.response["Error"]["Code"] == "NoSuchKey":
            return {
                "statusCode": 200,
                "headers": {
                    "Access-Control-Allow-Origin": "*"
                },
                "body": json.dumps({"status": "PENDING"})
            }
        else:
            raise